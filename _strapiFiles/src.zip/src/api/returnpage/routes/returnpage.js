'use strict';

/**
 * returnpage router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::returnpage.returnpage');
